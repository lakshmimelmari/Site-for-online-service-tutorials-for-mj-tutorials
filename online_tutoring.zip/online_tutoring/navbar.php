<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"  crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"  crossorigin="anonymous"></script>  

<link rel="stylesheet" href="style.css">
    <div class="navbar">
        <!--  -->
        
            <div class="col-md-3 mr-3 logo">
                <a href="index.php">
                    <h1 class="heading"><img src="img/mj_logo.jpg" class="img-fluid" heiht="80px"/> Tutorials</h1>        
                </a>
            </div>
            <div class="col-md-9">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid ml-5">
    
                    <!-- <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button> -->
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                    <button class="btn btn-outline-primary "><a class="nav-link active" aria-current="page" href="index.php"><h4>Home</h4></a></button>
                    </li>
                    <li class="nav-item">
                    <button class="btn btn-outline-primary "><a class="nav-link " aria-current="page" href="#"><h4>About Us</h4></a></button>
                    </li>
        
                    <li class="nav-item">
                    <button class="btn btn-outline-primary "><a class="nav-link " aria-current="page" href="#"><h4>Contact</h4></a></button>
                    </li>
     
                </ul>
                <button class="btn btn-outline-primary mx-2 "><a class="nav-link active" aria-current="page" href="admin_login.php"><h4>Admin</h4></a></button>
                <button class="btn btn-outline-primary mx-2 "><a class="nav-link active" aria-current="page" href="staff_login.php"><h4>Staff</h4></a></button>
                <button class="btn btn-outline-primary mx-2 "><a class="nav-link active" aria-current="page" href="student_login.php"><h4>Student</h4></a></button>
                
    
                    </div>
      
        
        
        
                </div>
            </nav>
        </div>
    </div>

    </div>