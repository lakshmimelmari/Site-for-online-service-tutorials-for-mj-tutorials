<?php 
    include 'navbar.php';
    include 'configure.php';
?>

<body>

</body>

<?php include 'footer.php'; ?>